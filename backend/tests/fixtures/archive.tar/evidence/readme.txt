DolosMeta tar fixture
