DolosMeta archive fixture
